def percent_change(old, new):
    return ((new - old) / old) * 100
